package order;
public class MainApplication
{
   public MainApplication()
   {
      // Create an instance of MyClass
      MyClass myObject = new MyClass();
      
      // Make the call to foo
      myObject.foo(1, "Kim");

   }

   public static void main(String[] args)
   {
      MainApplication application = new MainApplication();
   }
}
