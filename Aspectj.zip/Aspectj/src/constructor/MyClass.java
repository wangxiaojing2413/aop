package constructor;
public class MyClass
{
	private int number;
	private String name;

	public MyClass(int number, String name)
	{
		this.number = number;
		this.name = name;
	}


	public static final void main(String args[])
	{
		// Create an instance of the object
		MyClass myObject = new MyClass(123456, "Ron");
	}
}
