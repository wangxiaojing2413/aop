package aroundAdvice;

public class MyClass {
	public int foo() {
		System.out.println("Inside int foo ()");
		return 500;
	}

	public int bar(int value) {
		System.out.println("Inside int bar (int)");
		return 500;
	}

	public int baz() {
		System.out.println("Inside int baz ()");
		return 500;
	}
}