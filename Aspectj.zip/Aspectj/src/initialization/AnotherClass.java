package initialization;
public class AnotherClass {
	private int number;
	private String name;

	public AnotherClass(int number) {
		System.out.println("Initializing AnotherClass");
		this.number = number;
	}
}
