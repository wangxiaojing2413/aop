package aroundAdvice.src;

import java.io.PrintStream;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.JoinPoint.StaticPart;
import org.aspectj.lang.NoAspectBoundException;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.runtime.internal.AroundClosure;

@Aspect
public class AroundAdviceRecipe {
	static {
		try {
			ajc$postClinit();
		} catch (Throwable localThrowable) {
			ajc$initFailureCause = localThrowable;
		}

	}

	@Around(value = "(callFooPointCut() && !within(AroundAdviceRecipe+))", argNames = "ajc$aroundClosure")
	public int ajc$around$aroundAdvice_AroundAdviceRecipe$1$ae560da9(AroundClosure ajc$aroundClosure,
			JoinPoint thisJoinPoint) {
		System.out.println("------------------- Aspect Advice Logic --------------------");
		System.out.println("Signature: " + thisJoinPoint.getSignature());
		System.out.println("Source Location: " + thisJoinPoint.getStaticPart().getSourceLocation());
		System.out.println("------------------------------------------------------------");
		return ajc$around$aroundAdvice_AroundAdviceRecipe$1$ae560da9proceed(ajc$aroundClosure);
	}

	@Around(value = "(callBarPointCut(value) && !within(AroundAdviceRecipe+))", argNames = "value,ajc$aroundClosure")
	public int ajc$around$aroundAdvice_AroundAdviceRecipe$2$38f7ae3b(int value, AroundClosure ajc$aroundClosure,
			JoinPoint thisJoinPoint) {
		System.out.println("------------------- Aspect Advice Logic --------------------");
		System.out.println("Signature: " + thisJoinPoint.getSignature());
		System.out.println("Source Location: " + thisJoinPoint.getStaticPart().getSourceLocation());
		System.out.println("------------------------------------------------------------");
		return ajc$around$aroundAdvice_AroundAdviceRecipe$2$38f7ae3bproceed(value, ajc$aroundClosure);
	}

	@Around(value = "(callBazPointCut() && !within(AroundAdviceRecipe+))", argNames = "ajc$aroundClosure")
	public int ajc$around$aroundAdvice_AroundAdviceRecipe$3$b3d5bb34(AroundClosure ajc$aroundClosure,
			JoinPoint thisJoinPoint) {
		System.out.println("------------------- Aspect Advice Logic --------------------");
		System.out.println("Signature: " + thisJoinPoint.getSignature());
		System.out.println("Source Location: " + thisJoinPoint.getStaticPart().getSourceLocation());
		System.out.println("------------------------------------------------------------");
		return 200;
	}

	public static AroundAdviceRecipe aspectOf() {
		if (ajc$perSingletonInstance == null)
			throw new NoAspectBoundException("aroundAdvice_AroundAdviceRecipe", ajc$initFailureCause);
		return ajc$perSingletonInstance;
	}

	public static boolean hasAspect() {
		return ajc$perSingletonInstance != null;
	}

}

/*
 * Location: E:\soft\LearnSpacesForNeon\AspectJ02\bin\ Qualified Name:
 * aroundAdvice.AroundAdviceRecipe JD-Core Version: 0.6.2
 */