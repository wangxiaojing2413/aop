 package aroundAdvice.src;
 
 import java.io.PrintStream;
 import org.aspectj.lang.JoinPoint;
 import org.aspectj.lang.JoinPoint.StaticPart;
 import org.aspectj.runtime.internal.AroundClosure;
 import org.aspectj.runtime.reflect.Factory;
 
 public class MainClass
 {
   private static final JoinPoint.StaticPart ajc$tjp_0;
 
   public static void main(String[] args)
   {
     MyClass myObject = new MyClass();
 
     MyClass localMyClass1 = myObject; JoinPoint localJoinPoint = Factory.makeJP(ajc$tjp_0, null, localMyClass1); System.out.println("Returned value from foo: " + foo_aroundBody1$advice(localMyClass1, localJoinPoint, AroundAdviceRecipe.aspectOf(), null, localJoinPoint));
   }
 
   static
   {
     ajc$preClinit();
   }
 
   private static final int foo_aroundBody0(MyClass paramMyClass, JoinPoint paramJoinPoint)
   {
     return paramMyClass.foo();
   }
 
   private static final int foo_aroundBody1$advice(MyClass target, JoinPoint thisJoinPoint, AroundAdviceRecipe ajc$aspectInstance, AroundClosure ajc$aroundClosure, JoinPoint thisJoinPoint)
   {
     System.out.println("------------------- Aspect Advice Logic --------------------");
     System.out.println("Signature: " + thisJoinPoint.getSignature());
     System.out.println("Source Location: " + thisJoinPoint.getStaticPart().getSourceLocation());
     System.out.println("------------------------------------------------------------");
     AroundClosure localAroundClosure = ajc$aroundClosure; return foo_aroundBody0(target, thisJoinPoint);
   }
 
   private static void ajc$preClinit()
   {
     Factory localFactory = new Factory("MainClass.java", MainClass.class); ajc$tjp_0 = localFactory.makeSJP("method-call", localFactory.makeMethodSig("1", "foo", "aroundAdvice.MyClass", "", "", "", "int"), 8);
   }
 }

/* Location:           E:\soft\LearnSpacesForNeon\AspectJ02\bin\
 * Qualified Name:     aroundAdvice.MainClass
 * JD-Core Version:    0.6.2
 */