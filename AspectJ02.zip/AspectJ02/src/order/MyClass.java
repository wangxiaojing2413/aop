package order;
public class MyClass
{	
	public void foo(int number, String name)
	{
		System.out.println("Inside foo (int, String)");
	}
}